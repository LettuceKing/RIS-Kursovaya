create
    definer = root@localhost procedure orders(IN id_invoice int)
BEGIN
DECLARE DONE INTEGER DEFAULT 0;
DECLARE new_date DATE;
DECLARE new_count INTEGER;
DECLARE C1 CURSOR FOR
	SELECT inv_date, count
	FROM invoice JOIN invoice_str USING(inv_id);
DECLARE EXIT HANDLER FOR SQLSTATE '02000' SET DONE = 1;
OPEN C1;
WHILE DONE = 0 DO
	FETCH C1 INTO new_date, new_count;
    UPDATE invoice_str
		SET count = new_count;
	UPDATE invoice
		SET inv_date = new_date;
END WHILE;
CLOSE C1;
END;

