create definer = root@localhost trigger invoice_str_AFTER_INSERT
    after insert
    on invoice_str
    for each row
BEGIN
	DECLARE new_count int;
    DECLARE new_date date;
    DECLARE new_blank int;
    DECLARE new_price int;
    SET new_count = new.count;
    SET new_blank = new.blank_id;
    SET new_price = new.price;
    SELECT inv_date INTO new_date
    FROM invoice
    WHERE inv_id = new.inv_id;
    UPDATE blanks_store
		SET count = count + new_count,
			last_update = new_date
	WHERE blanks_store.blank_id = new_blank AND blanks_store.price = new_price;
END;

